package com.occ.interview.takehome;

import java.util.List;

public interface FileScore {
    public int getTotalScore(List<String> records);
}
